--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.6
-- Dumped by pg_dump version 14.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: enterpriseapplications; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA enterpriseapplications;


ALTER SCHEMA enterpriseapplications OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: addresses; Type: TABLE; Schema: enterpriseapplications; Owner: postgres
--

CREATE TABLE enterpriseapplications.addresses (
    created_date date NOT NULL,
    last_modified_date date NOT NULL,
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    country_code character varying(255) NOT NULL,
    locality character varying(255) NOT NULL,
    owner_name character varying(255) NOT NULL,
    postal_code character varying(255) NOT NULL,
    street character varying(255) NOT NULL,
    CONSTRAINT addresses_country_code_check CHECK (((country_code)::text = ANY ((ARRAY['ITA'::character varying, 'EN'::character varying, 'FR'::character varying, 'DE'::character varying])::text[])))
);


ALTER TABLE enterpriseapplications.addresses OWNER TO postgres;

--
-- Name: bans; Type: TABLE; Schema: enterpriseapplications; Owner: postgres
--

CREATE TABLE enterpriseapplications.bans (
    created_date date NOT NULL,
    expiration_date date NOT NULL,
    expired boolean NOT NULL,
    last_modified_date date NOT NULL,
    banned uuid NOT NULL,
    banner uuid,
    id uuid NOT NULL,
    description character varying(255) NOT NULL,
    reason character varying(255) NOT NULL,
    CONSTRAINT bans_reason_check CHECK (((reason)::text = ANY ((ARRAY['NUDITY'::character varying, 'RACISM'::character varying])::text[])))
);


ALTER TABLE enterpriseapplications.bans OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: enterpriseapplications; Owner: postgres
--

CREATE TABLE enterpriseapplications.categories (
    created_date date,
    last_modified_date date,
    id uuid NOT NULL,
    primary_cat character varying(255) NOT NULL,
    secondary_cat character varying(255) NOT NULL,
    tertiary_cat character varying(255) NOT NULL
);


ALTER TABLE enterpriseapplications.categories OWNER TO postgres;

--
-- Name: conversations; Type: TABLE; Schema: enterpriseapplications; Owner: postgres
--

CREATE TABLE enterpriseapplications.conversations (
    created_date date NOT NULL,
    last_modified_date date NOT NULL,
    id uuid NOT NULL,
    product_id uuid NOT NULL,
    starter_id uuid NOT NULL
);


ALTER TABLE enterpriseapplications.conversations OWNER TO postgres;

--
-- Name: follows; Type: TABLE; Schema: enterpriseapplications; Owner: postgres
--

CREATE TABLE enterpriseapplications.follows (
    created_date date NOT NULL,
    last_modified_date date NOT NULL,
    followed_id uuid NOT NULL,
    follower_id uuid NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE enterpriseapplications.follows OWNER TO postgres;

--
-- Name: images; Type: TABLE; Schema: enterpriseapplications; Owner: postgres
--

CREATE TABLE enterpriseapplications.images (
    created_date date NOT NULL,
    last_modified_date date NOT NULL,
    type smallint NOT NULL,
    id uuid NOT NULL,
    image bytea NOT NULL,
    CONSTRAINT images_type_check CHECK (((type >= 0) AND (type <= 1)))
);


ALTER TABLE enterpriseapplications.images OWNER TO postgres;

--
-- Name: likes; Type: TABLE; Schema: enterpriseapplications; Owner: postgres
--

CREATE TABLE enterpriseapplications.likes (
    created_date date NOT NULL,
    last_modified_date date NOT NULL,
    id uuid NOT NULL,
    product_id uuid NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE enterpriseapplications.likes OWNER TO postgres;

--
-- Name: message_reports; Type: TABLE; Schema: enterpriseapplications; Owner: postgres
--

CREATE TABLE enterpriseapplications.message_reports (
    id uuid NOT NULL,
    message_id uuid NOT NULL
);


ALTER TABLE enterpriseapplications.message_reports OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: enterpriseapplications; Owner: postgres
--

CREATE TABLE enterpriseapplications.messages (
    created_date timestamp(6) without time zone NOT NULL,
    conversation_id uuid,
    id uuid NOT NULL,
    receiver_id uuid NOT NULL,
    sender_id uuid NOT NULL,
    text character varying(255) NOT NULL
);


ALTER TABLE enterpriseapplications.messages OWNER TO postgres;

--
-- Name: offers; Type: TABLE; Schema: enterpriseapplications; Owner: postgres
--

CREATE TABLE enterpriseapplications.offers (
    created_date date NOT NULL,
    expiration_date date NOT NULL,
    expired boolean NOT NULL,
    last_modified_date date NOT NULL,
    price numeric(38,2) NOT NULL,
    buyer_id uuid NOT NULL,
    id uuid NOT NULL,
    product_id uuid NOT NULL,
    description character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    CONSTRAINT offers_status_check CHECK (((status)::text = ANY ((ARRAY['OPEN'::character varying, 'REJECTED'::character varying, 'ACCEPTED'::character varying, 'EXPIRED'::character varying])::text[])))
);


ALTER TABLE enterpriseapplications.offers OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: enterpriseapplications; Owner: postgres
--

CREATE TABLE enterpriseapplications.orders (
    created_date date NOT NULL,
    delivery_date date NOT NULL,
    last_modified_date date NOT NULL,
    price numeric(38,2) NOT NULL,
    address_id uuid NOT NULL,
    buyer uuid NOT NULL,
    id uuid NOT NULL,
    payment_method_id uuid NOT NULL,
    product_id uuid NOT NULL,
    status character varying(255) NOT NULL,
    CONSTRAINT orders_status_check CHECK (((status)::text = ANY ((ARRAY['PROCESSING'::character varying, 'SHIPPING'::character varying, 'DELIVERED'::character varying])::text[])))
);


ALTER TABLE enterpriseapplications.orders OWNER TO postgres;

--
-- Name: payment_methods; Type: TABLE; Schema: enterpriseapplications; Owner: postgres
--

CREATE TABLE enterpriseapplications.payment_methods (
    brand smallint NOT NULL,
    created_date date NOT NULL,
    expiration_date date NOT NULL,
    last_modified_date date NOT NULL,
    id uuid NOT NULL,
    owner uuid NOT NULL,
    holder_name character varying(255) NOT NULL,
    number character varying(255) NOT NULL,
    CONSTRAINT payment_methods_brand_check CHECK (((brand >= 0) AND (brand <= 3)))
);


ALTER TABLE enterpriseapplications.payment_methods OWNER TO postgres;

--
-- Name: product_images; Type: TABLE; Schema: enterpriseapplications; Owner: postgres
--

CREATE TABLE enterpriseapplications.product_images (
    id uuid NOT NULL,
    product_id uuid
);


ALTER TABLE enterpriseapplications.product_images OWNER TO postgres;

--
-- Name: product_reports; Type: TABLE; Schema: enterpriseapplications; Owner: postgres
--

CREATE TABLE enterpriseapplications.product_reports (
    id uuid NOT NULL,
    reported_product uuid NOT NULL
);


ALTER TABLE enterpriseapplications.product_reports OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: enterpriseapplications; Owner: postgres
--

CREATE TABLE enterpriseapplications.products (
    created_date date NOT NULL,
    last_modified_date date NOT NULL,
    min_price numeric(38,2) NOT NULL,
    price numeric(38,2) NOT NULL,
    category_id uuid NOT NULL,
    product_id uuid NOT NULL,
    seller_id uuid NOT NULL,
    brand character varying(20) NOT NULL,
    name character varying(20) NOT NULL,
    description character varying(200) NOT NULL,
    condition character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    visibility character varying(255) NOT NULL,
    CONSTRAINT products_condition_check CHECK (((condition)::text = ANY ((ARRAY['NEW'::character varying, 'ALMOST_NEW'::character varying, 'USED'::character varying])::text[]))),
    CONSTRAINT products_status_check CHECK (((status)::text = ANY ((ARRAY['AVAILABLE'::character varying, 'BOUGHT'::character varying])::text[]))),
    CONSTRAINT products_visibility_check CHECK (((visibility)::text = ANY ((ARRAY['PUBLIC'::character varying, 'PRIVATE'::character varying])::text[])))
);


ALTER TABLE enterpriseapplications.products OWNER TO postgres;

--
-- Name: replies; Type: TABLE; Schema: enterpriseapplications; Owner: postgres
--

CREATE TABLE enterpriseapplications.replies (
    created_date date NOT NULL,
    last_modified_date date NOT NULL,
    id uuid NOT NULL,
    review_id uuid NOT NULL,
    writer uuid NOT NULL,
    text character varying(255) NOT NULL
);


ALTER TABLE enterpriseapplications.replies OWNER TO postgres;

--
-- Name: reports; Type: TABLE; Schema: enterpriseapplications; Owner: postgres
--

CREATE TABLE enterpriseapplications.reports (
    created_date date NOT NULL,
    last_modified_date date NOT NULL,
    id uuid NOT NULL,
    reported_id uuid NOT NULL,
    reporter_id uuid NOT NULL,
    description character varying(255) NOT NULL,
    reason character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    CONSTRAINT reports_reason_check CHECK (((reason)::text = ANY ((ARRAY['NUDITY'::character varying, 'RACISM'::character varying])::text[]))),
    CONSTRAINT reports_type_check CHECK (((type)::text = ANY ((ARRAY['USER'::character varying, 'MESSAGE'::character varying, 'PRODUCT'::character varying])::text[])))
);


ALTER TABLE enterpriseapplications.reports OWNER TO postgres;

--
-- Name: reviews; Type: TABLE; Schema: enterpriseapplications; Owner: postgres
--

CREATE TABLE enterpriseapplications.reviews (
    created_date date NOT NULL,
    last_modified_date date NOT NULL,
    rating integer NOT NULL,
    id uuid NOT NULL,
    receiver_id uuid NOT NULL,
    writer_id uuid NOT NULL,
    text character varying(255) NOT NULL
);


ALTER TABLE enterpriseapplications.reviews OWNER TO postgres;

--
-- Name: user_images; Type: TABLE; Schema: enterpriseapplications; Owner: postgres
--

CREATE TABLE enterpriseapplications.user_images (
    id uuid NOT NULL,
    user_id uuid
);


ALTER TABLE enterpriseapplications.user_images OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: enterpriseapplications; Owner: postgres
--

CREATE TABLE enterpriseapplications.users (
    created_date date NOT NULL,
    last_modified_date date NOT NULL,
    rating bigint,
    id uuid NOT NULL,
    description character varying(255),
    email character varying(255) NOT NULL,
    gender character varying(255) NOT NULL,
    name character varying(255),
    surname character varying(255),
    username character varying(255) NOT NULL,
    visibility character varying(255) NOT NULL,
    CONSTRAINT users_gender_check CHECK (((gender)::text = ANY ((ARRAY['MALE'::character varying, 'FEMALE'::character varying, 'NOT_SPECIFIED'::character varying])::text[]))),
    CONSTRAINT users_visibility_check CHECK (((visibility)::text = ANY ((ARRAY['PUBLIC'::character varying, 'PRIVATE'::character varying])::text[])))
);


ALTER TABLE enterpriseapplications.users OWNER TO postgres;

--
-- Data for Name: addresses; Type: TABLE DATA; Schema: enterpriseapplications; Owner: postgres
--

COPY enterpriseapplications.addresses (created_date, last_modified_date, id, user_id, country_code, locality, owner_name, postal_code, street) FROM stdin;
\.
COPY enterpriseapplications.addresses (created_date, last_modified_date, id, user_id, country_code, locality, owner_name, postal_code, street) FROM '$$PATH$$/3563.dat';

--
-- Data for Name: bans; Type: TABLE DATA; Schema: enterpriseapplications; Owner: postgres
--

COPY enterpriseapplications.bans (created_date, expiration_date, expired, last_modified_date, banned, banner, id, description, reason) FROM stdin;
\.
COPY enterpriseapplications.bans (created_date, expiration_date, expired, last_modified_date, banned, banner, id, description, reason) FROM '$$PATH$$/3564.dat';

--
-- Data for Name: categories; Type: TABLE DATA; Schema: enterpriseapplications; Owner: postgres
--

COPY enterpriseapplications.categories (created_date, last_modified_date, id, primary_cat, secondary_cat, tertiary_cat) FROM stdin;
\.
COPY enterpriseapplications.categories (created_date, last_modified_date, id, primary_cat, secondary_cat, tertiary_cat) FROM '$$PATH$$/3565.dat';

--
-- Data for Name: conversations; Type: TABLE DATA; Schema: enterpriseapplications; Owner: postgres
--

COPY enterpriseapplications.conversations (created_date, last_modified_date, id, product_id, starter_id) FROM stdin;
\.
COPY enterpriseapplications.conversations (created_date, last_modified_date, id, product_id, starter_id) FROM '$$PATH$$/3566.dat';

--
-- Data for Name: follows; Type: TABLE DATA; Schema: enterpriseapplications; Owner: postgres
--

COPY enterpriseapplications.follows (created_date, last_modified_date, followed_id, follower_id, id) FROM stdin;
\.
COPY enterpriseapplications.follows (created_date, last_modified_date, followed_id, follower_id, id) FROM '$$PATH$$/3567.dat';

--
-- Data for Name: images; Type: TABLE DATA; Schema: enterpriseapplications; Owner: postgres
--

COPY enterpriseapplications.images (created_date, last_modified_date, type, id, image) FROM stdin;
\.
COPY enterpriseapplications.images (created_date, last_modified_date, type, id, image) FROM '$$PATH$$/3568.dat';

--
-- Data for Name: likes; Type: TABLE DATA; Schema: enterpriseapplications; Owner: postgres
--

COPY enterpriseapplications.likes (created_date, last_modified_date, id, product_id, user_id) FROM stdin;
\.
COPY enterpriseapplications.likes (created_date, last_modified_date, id, product_id, user_id) FROM '$$PATH$$/3569.dat';

--
-- Data for Name: message_reports; Type: TABLE DATA; Schema: enterpriseapplications; Owner: postgres
--

COPY enterpriseapplications.message_reports (id, message_id) FROM stdin;
\.
COPY enterpriseapplications.message_reports (id, message_id) FROM '$$PATH$$/3570.dat';

--
-- Data for Name: messages; Type: TABLE DATA; Schema: enterpriseapplications; Owner: postgres
--

COPY enterpriseapplications.messages (created_date, conversation_id, id, receiver_id, sender_id, text) FROM stdin;
\.
COPY enterpriseapplications.messages (created_date, conversation_id, id, receiver_id, sender_id, text) FROM '$$PATH$$/3571.dat';

--
-- Data for Name: offers; Type: TABLE DATA; Schema: enterpriseapplications; Owner: postgres
--

COPY enterpriseapplications.offers (created_date, expiration_date, expired, last_modified_date, price, buyer_id, id, product_id, description, status) FROM stdin;
\.
COPY enterpriseapplications.offers (created_date, expiration_date, expired, last_modified_date, price, buyer_id, id, product_id, description, status) FROM '$$PATH$$/3572.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: enterpriseapplications; Owner: postgres
--

COPY enterpriseapplications.orders (created_date, delivery_date, last_modified_date, price, address_id, buyer, id, payment_method_id, product_id, status) FROM stdin;
\.
COPY enterpriseapplications.orders (created_date, delivery_date, last_modified_date, price, address_id, buyer, id, payment_method_id, product_id, status) FROM '$$PATH$$/3573.dat';

--
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: enterpriseapplications; Owner: postgres
--

COPY enterpriseapplications.payment_methods (brand, created_date, expiration_date, last_modified_date, id, owner, holder_name, number) FROM stdin;
\.
COPY enterpriseapplications.payment_methods (brand, created_date, expiration_date, last_modified_date, id, owner, holder_name, number) FROM '$$PATH$$/3574.dat';

--
-- Data for Name: product_images; Type: TABLE DATA; Schema: enterpriseapplications; Owner: postgres
--

COPY enterpriseapplications.product_images (id, product_id) FROM stdin;
\.
COPY enterpriseapplications.product_images (id, product_id) FROM '$$PATH$$/3575.dat';

--
-- Data for Name: product_reports; Type: TABLE DATA; Schema: enterpriseapplications; Owner: postgres
--

COPY enterpriseapplications.product_reports (id, reported_product) FROM stdin;
\.
COPY enterpriseapplications.product_reports (id, reported_product) FROM '$$PATH$$/3576.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: enterpriseapplications; Owner: postgres
--

COPY enterpriseapplications.products (created_date, last_modified_date, min_price, price, category_id, product_id, seller_id, brand, name, description, condition, status, visibility) FROM stdin;
\.
COPY enterpriseapplications.products (created_date, last_modified_date, min_price, price, category_id, product_id, seller_id, brand, name, description, condition, status, visibility) FROM '$$PATH$$/3577.dat';

--
-- Data for Name: replies; Type: TABLE DATA; Schema: enterpriseapplications; Owner: postgres
--

COPY enterpriseapplications.replies (created_date, last_modified_date, id, review_id, writer, text) FROM stdin;
\.
COPY enterpriseapplications.replies (created_date, last_modified_date, id, review_id, writer, text) FROM '$$PATH$$/3578.dat';

--
-- Data for Name: reports; Type: TABLE DATA; Schema: enterpriseapplications; Owner: postgres
--

COPY enterpriseapplications.reports (created_date, last_modified_date, id, reported_id, reporter_id, description, reason, type) FROM stdin;
\.
COPY enterpriseapplications.reports (created_date, last_modified_date, id, reported_id, reporter_id, description, reason, type) FROM '$$PATH$$/3579.dat';

--
-- Data for Name: reviews; Type: TABLE DATA; Schema: enterpriseapplications; Owner: postgres
--

COPY enterpriseapplications.reviews (created_date, last_modified_date, rating, id, receiver_id, writer_id, text) FROM stdin;
\.
COPY enterpriseapplications.reviews (created_date, last_modified_date, rating, id, receiver_id, writer_id, text) FROM '$$PATH$$/3580.dat';

--
-- Data for Name: user_images; Type: TABLE DATA; Schema: enterpriseapplications; Owner: postgres
--

COPY enterpriseapplications.user_images (id, user_id) FROM stdin;
\.
COPY enterpriseapplications.user_images (id, user_id) FROM '$$PATH$$/3581.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: enterpriseapplications; Owner: postgres
--

COPY enterpriseapplications.users (created_date, last_modified_date, rating, id, description, email, gender, name, surname, username, visibility) FROM stdin;
\.
COPY enterpriseapplications.users (created_date, last_modified_date, rating, id, description, email, gender, name, surname, username, visibility) FROM '$$PATH$$/3582.dat';

--
-- Name: addresses addresses_pkey; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.addresses
    ADD CONSTRAINT addresses_pkey PRIMARY KEY (id);


--
-- Name: bans bans_pkey; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.bans
    ADD CONSTRAINT bans_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: follows follows_pkey; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.follows
    ADD CONSTRAINT follows_pkey PRIMARY KEY (id);


--
-- Name: images images_pkey; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.images
    ADD CONSTRAINT images_pkey PRIMARY KEY (id);


--
-- Name: likes likes_pkey; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.likes
    ADD CONSTRAINT likes_pkey PRIMARY KEY (id);


--
-- Name: message_reports message_reports_pkey; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.message_reports
    ADD CONSTRAINT message_reports_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: offers offers_pkey; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.offers
    ADD CONSTRAINT offers_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: orders orders_product_id_key; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.orders
    ADD CONSTRAINT orders_product_id_key UNIQUE (product_id);


--
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- Name: product_images product_images_pkey; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.product_images
    ADD CONSTRAINT product_images_pkey PRIMARY KEY (id);


--
-- Name: product_reports product_reports_pkey; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.product_reports
    ADD CONSTRAINT product_reports_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (product_id);


--
-- Name: replies replies_pkey; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.replies
    ADD CONSTRAINT replies_pkey PRIMARY KEY (id);


--
-- Name: replies replies_review_id_key; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.replies
    ADD CONSTRAINT replies_review_id_key UNIQUE (review_id);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: conversations uk3ykkiuuj1epilcsvdavm9qrux; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.conversations
    ADD CONSTRAINT uk3ykkiuuj1epilcsvdavm9qrux UNIQUE (starter_id, product_id);


--
-- Name: likes uk96hcuob8dxvglp2sv48rfr9im; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.likes
    ADD CONSTRAINT uk96hcuob8dxvglp2sv48rfr9im UNIQUE (user_id, product_id);


--
-- Name: reviews ukaobks99fk8kvtu7m5144o5hwl; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.reviews
    ADD CONSTRAINT ukaobks99fk8kvtu7m5144o5hwl UNIQUE (writer_id, receiver_id);


--
-- Name: messages ukbvd4ibpe8qr1kfvwhv9o1jxyd; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.messages
    ADD CONSTRAINT ukbvd4ibpe8qr1kfvwhv9o1jxyd UNIQUE (sender_id, receiver_id, created_date);


--
-- Name: follows ukbwuo2irxjmlexrfsmrwols8c3; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.follows
    ADD CONSTRAINT ukbwuo2irxjmlexrfsmrwols8c3 UNIQUE (followed_id, follower_id);


--
-- Name: reports ukdp06ov4oq4esmtgyditpi1heg; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.reports
    ADD CONSTRAINT ukdp06ov4oq4esmtgyditpi1heg UNIQUE (reporter_id, reported_id, type);


--
-- Name: offers ukfqicpi2uk75wgpm86a3oxv2vt; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.offers
    ADD CONSTRAINT ukfqicpi2uk75wgpm86a3oxv2vt UNIQUE (buyer_id, product_id);


--
-- Name: user_images user_images_pkey; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.user_images
    ADD CONSTRAINT user_images_pkey PRIMARY KEY (id);


--
-- Name: user_images user_images_user_id_key; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.user_images
    ADD CONSTRAINT user_images_user_id_key UNIQUE (user_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: addresses fk1fa36y2oqhao3wgg2rw1pi459; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.addresses
    ADD CONSTRAINT fk1fa36y2oqhao3wgg2rw1pi459 FOREIGN KEY (user_id) REFERENCES enterpriseapplications.users(id);


--
-- Name: bans fk45lt2lybbxdlhge4t5gd0aq0c; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.bans
    ADD CONSTRAINT fk45lt2lybbxdlhge4t5gd0aq0c FOREIGN KEY (banner) REFERENCES enterpriseapplications.users(id);


--
-- Name: follows fk45sy1jkos9oy1j4by9y7225nm; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.follows
    ADD CONSTRAINT fk45sy1jkos9oy1j4by9y7225nm FOREIGN KEY (followed_id) REFERENCES enterpriseapplications.users(id);


--
-- Name: messages fk4ui4nnwntodh6wjvck53dbk9m; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.messages
    ADD CONSTRAINT fk4ui4nnwntodh6wjvck53dbk9m FOREIGN KEY (sender_id) REFERENCES enterpriseapplications.users(id);


--
-- Name: conversations fk55unb64p716d8hko5m1favthl; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.conversations
    ADD CONSTRAINT fk55unb64p716d8hko5m1favthl FOREIGN KEY (starter_id) REFERENCES enterpriseapplications.users(id);


--
-- Name: reviews fk77qnqsbwjkgvrto39r56vv03b; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.reviews
    ADD CONSTRAINT fk77qnqsbwjkgvrto39r56vv03b FOREIGN KEY (receiver_id) REFERENCES enterpriseapplications.users(id);


--
-- Name: message_reports fk77va9lugu5ei09uruv55nq5t9; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.message_reports
    ADD CONSTRAINT fk77va9lugu5ei09uruv55nq5t9 FOREIGN KEY (message_id) REFERENCES enterpriseapplications.messages(id);


--
-- Name: likes fk79ytfme5tdc4k9i57h0akaah2; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.likes
    ADD CONSTRAINT fk79ytfme5tdc4k9i57h0akaah2 FOREIGN KEY (product_id) REFERENCES enterpriseapplications.products(product_id);


--
-- Name: user_images fk7dxnl4odgndcyafvfg0dwxq3i; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.user_images
    ADD CONSTRAINT fk7dxnl4odgndcyafvfg0dwxq3i FOREIGN KEY (id) REFERENCES enterpriseapplications.images(id);


--
-- Name: orders fka03ljb6t6oa6mqtoifuwkb0kw; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.orders
    ADD CONSTRAINT fka03ljb6t6oa6mqtoifuwkb0kw FOREIGN KEY (payment_method_id) REFERENCES enterpriseapplications.payment_methods(id);


--
-- Name: payment_methods fkajhsdqid9wwinc8sjfaiifut9; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.payment_methods
    ADD CONSTRAINT fkajhsdqid9wwinc8sjfaiifut9 FOREIGN KEY (owner) REFERENCES enterpriseapplications.users(id);


--
-- Name: product_reports fkanyrnyb3my143hquc8bmdm2vo; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.product_reports
    ADD CONSTRAINT fkanyrnyb3my143hquc8bmdm2vo FOREIGN KEY (reported_product) REFERENCES enterpriseapplications.products(product_id);


--
-- Name: replies fkbf77p21qvc3gf5won8fkfa7ms; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.replies
    ADD CONSTRAINT fkbf77p21qvc3gf5won8fkfa7ms FOREIGN KEY (review_id) REFERENCES enterpriseapplications.reviews(id);


--
-- Name: products fkbgw3lyxhsml3kfqnfr45o0vbj; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.products
    ADD CONSTRAINT fkbgw3lyxhsml3kfqnfr45o0vbj FOREIGN KEY (seller_id) REFERENCES enterpriseapplications.users(id);


--
-- Name: reports fkd3qiw2om5d2oh5xb7fbdcq225; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.reports
    ADD CONSTRAINT fkd3qiw2om5d2oh5xb7fbdcq225 FOREIGN KEY (reporter_id) REFERENCES enterpriseapplications.users(id);


--
-- Name: reviews fkf0l51dg2l9fd7r3q1s71hwdod; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.reviews
    ADD CONSTRAINT fkf0l51dg2l9fd7r3q1s71hwdod FOREIGN KEY (writer_id) REFERENCES enterpriseapplications.users(id);


--
-- Name: offers fkgc18i3k5pqq7ik9x23nw0ndau; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.offers
    ADD CONSTRAINT fkgc18i3k5pqq7ik9x23nw0ndau FOREIGN KEY (buyer_id) REFERENCES enterpriseapplications.users(id);


--
-- Name: product_images fkhf6x81rw90r56j8wohrrnd63p; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.product_images
    ADD CONSTRAINT fkhf6x81rw90r56j8wohrrnd63p FOREIGN KEY (id) REFERENCES enterpriseapplications.images(id);


--
-- Name: orders fkhlglkvf5i60dv6dn397ethgpt; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.orders
    ADD CONSTRAINT fkhlglkvf5i60dv6dn397ethgpt FOREIGN KEY (address_id) REFERENCES enterpriseapplications.addresses(id);


--
-- Name: product_reports fkhpu49lc78ualv4bkpaabat8t6; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.product_reports
    ADD CONSTRAINT fkhpu49lc78ualv4bkpaabat8t6 FOREIGN KEY (id) REFERENCES enterpriseapplications.reports(id);


--
-- Name: offers fkjf1jh3h4v4m7diel8vvhmuqas; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.offers
    ADD CONSTRAINT fkjf1jh3h4v4m7diel8vvhmuqas FOREIGN KEY (product_id) REFERENCES enterpriseapplications.products(product_id);


--
-- Name: replies fkjy8uw57sy6q2mnl0c7l67gv5; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.replies
    ADD CONSTRAINT fkjy8uw57sy6q2mnl0c7l67gv5 FOREIGN KEY (writer) REFERENCES enterpriseapplications.users(id);


--
-- Name: orders fkkp5k52qtiygd8jkag4hayd0qg; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.orders
    ADD CONSTRAINT fkkp5k52qtiygd8jkag4hayd0qg FOREIGN KEY (product_id) REFERENCES enterpriseapplications.products(product_id);


--
-- Name: bans fkkwmo747g97mu6rtpfe9p1xkgv; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.bans
    ADD CONSTRAINT fkkwmo747g97mu6rtpfe9p1xkgv FOREIGN KEY (banned) REFERENCES enterpriseapplications.users(id);


--
-- Name: user_images fkl1lf9kxrd8ybmovqsxcuxhw42; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.user_images
    ADD CONSTRAINT fkl1lf9kxrd8ybmovqsxcuxhw42 FOREIGN KEY (user_id) REFERENCES enterpriseapplications.users(id);


--
-- Name: orders fkljvc97l19m7cnlopv8535hijx; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.orders
    ADD CONSTRAINT fkljvc97l19m7cnlopv8535hijx FOREIGN KEY (buyer) REFERENCES enterpriseapplications.users(id);


--
-- Name: likes fknvx9seeqqyy71bij291pwiwrg; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.likes
    ADD CONSTRAINT fknvx9seeqqyy71bij291pwiwrg FOREIGN KEY (user_id) REFERENCES enterpriseapplications.users(id);


--
-- Name: message_reports fko21u5cka4twbs8rtlpysuxk60; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.message_reports
    ADD CONSTRAINT fko21u5cka4twbs8rtlpysuxk60 FOREIGN KEY (id) REFERENCES enterpriseapplications.reports(id);


--
-- Name: products fkog2rp4qthbtt2lfyhfo32lsw9; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.products
    ADD CONSTRAINT fkog2rp4qthbtt2lfyhfo32lsw9 FOREIGN KEY (category_id) REFERENCES enterpriseapplications.categories(id);


--
-- Name: follows fkqnkw0cwwh6572nyhvdjqlr163; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.follows
    ADD CONSTRAINT fkqnkw0cwwh6572nyhvdjqlr163 FOREIGN KEY (follower_id) REFERENCES enterpriseapplications.users(id);


--
-- Name: product_images fkqnq71xsohugpqwf3c9gxmsuy; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.product_images
    ADD CONSTRAINT fkqnq71xsohugpqwf3c9gxmsuy FOREIGN KEY (product_id) REFERENCES enterpriseapplications.products(product_id);


--
-- Name: conversations fkqy0ufa6yoqyqsqkdfll9hp24a; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.conversations
    ADD CONSTRAINT fkqy0ufa6yoqyqsqkdfll9hp24a FOREIGN KEY (product_id) REFERENCES enterpriseapplications.products(product_id);


--
-- Name: reports fks5hp3xww9pl0bwblxl3cfwue2; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.reports
    ADD CONSTRAINT fks5hp3xww9pl0bwblxl3cfwue2 FOREIGN KEY (reported_id) REFERENCES enterpriseapplications.users(id);


--
-- Name: messages fkt05r0b6n0iis8u7dfna4xdh73; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.messages
    ADD CONSTRAINT fkt05r0b6n0iis8u7dfna4xdh73 FOREIGN KEY (receiver_id) REFERENCES enterpriseapplications.users(id);


--
-- Name: messages fkt492th6wsovh1nush5yl5jj8e; Type: FK CONSTRAINT; Schema: enterpriseapplications; Owner: postgres
--

ALTER TABLE ONLY enterpriseapplications.messages
    ADD CONSTRAINT fkt492th6wsovh1nush5yl5jj8e FOREIGN KEY (conversation_id) REFERENCES enterpriseapplications.conversations(id);


--
-- PostgreSQL database dump complete
--

